docker container run -ti -v $2:/work bigpapoo/sae103-qrcode qrencode -o code.png "https://bigbrain.biz/$iso"

