#!/bin/bash

# TODO automatisé, récupérer les données
# php ./script2.php
# ./qrcode.bash
# ./scriptAvatar.bash
# php ./scriptHtmlnew.php
# contenairisé
